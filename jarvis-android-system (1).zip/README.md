# Jarvis System Assistant (Android APK)

Native Android system-level assistant connected to your **Jarvis Live** backend.

## Included System Features
- **Sleek Translucent Edge-Dock Handle** (`SYSTEM_ALERT_WINDOW` + Foreground Service) — minimal edge-snapping pill tab that never blocks your screen; tap anytime to speak or long-press to open Jarvis.
- **Full Phone UI & Hardware Control** (`AccessibilityService`) — go Back, Home, Recents, Lock Screen, Screenshot, Notifications, Quick Settings, Scroll Up/Down, Tap on-screen text, Type text, Volume/Mute, Media Play/Pause/Next/Prev, Flashlight, Alarms & Timers, Calls/SMS/WhatsApp, Camera, YouTube/Google Search.
- **Default Digital Assistant** (`android.intent.action.ASSIST`) — trigger Jarvis from your phone's assistant gesture or power-button long press.
- **Away Auto-Reply Service** (`NotificationListenerService`) — reads incoming WhatsApp / SMS / Messenger / Telegram notifications when Away Mode is ON and sends warm, human-like replies via `RemoteInput`.
- **Natural Human AI Companion** — connect once via **Google কানেক্ট** inside the app to talk naturally in Bengali or English using Gemini + Natural Voice.

## Build APK Using GitHub Actions (No PC Required)
1. Create a new GitHub repository and upload all files from this ZIP (keep the `.github/workflows/build-apk.yml` folder intact).
2. Open the **Actions** tab in your GitHub repository and download **Jarvis-System-APK** (`app-debug.apk`).
3. Open **Jarvis System**, tap **Google কানেক্ট**, and turn on **Overlay**, **Control**, **Notif**, **Calls**, and **Assist**.
