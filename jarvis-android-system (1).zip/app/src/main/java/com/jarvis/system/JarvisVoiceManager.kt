package com.jarvis.system

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class JarvisVoiceManager(
    private val context: Context,
    private val apiClient: JarvisApiClient
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var pendingDeviceDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val lang = JarvisPrefs(context).language
                tts?.language = if (lang == "en-US") Locale.US else Locale("bn", "BD")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            pendingDeviceDone?.invoke()
                            pendingDeviceDone = null
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            pendingDeviceDone?.invoke()
                            pendingDeviceDone = null
                        }
                    }
                })
            }
        }
    }

    fun startSingleListen(
        onListening: () -> Unit,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                onError("Voice recognition unavailable on this device")
                return@post
            }
            speechRecognizer?.destroy()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = recognizer

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = onListening()
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    onError("Speech error ($error)")
                }
                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = list?.firstOrNull()?.trim().orEmpty()
                    if (spoken.isNotBlank()) onResult(spoken) else onError("No speech detected")
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, JarvisPrefs(context).language)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer.startListening(intent)
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        CoroutineScope(Dispatchers.Main).launch {
            val wavBytes = apiClient.fetchNaturalTtsWav(text)
            if (wavBytes != null) {
                try {
                    val tempFile = File.createTempFile("jarvis_tts_", ".wav", context.cacheDir)
                    tempFile.writeBytes(wavBytes)
                    mediaPlayer?.release()
                    mediaPlayer = MediaPlayer().apply {
                        setDataSource(tempFile.absolutePath)
                        setOnCompletionListener {
                            tempFile.delete()
                            onDone?.invoke()
                        }
                        setOnErrorListener { _, _, _ ->
                            tempFile.delete()
                            speakDeviceTts(text, onDone)
                            true
                        }
                        prepare()
                        start()
                    }
                    return@launch
                } catch (_: Exception) {
                    // Fallback to device TTS
                }
            }
            speakDeviceTts(text, onDone)
        }
    }

    private fun speakDeviceTts(text: String, onDone: (() -> Unit)?) {
        val engine = tts
        if (engine == null) {
            onDone?.invoke()
            return
        }
        val lang = JarvisPrefs(context).language
        engine.language = if (lang == "en-US") Locale.US else Locale("bn", "BD")
        pendingDeviceDone = onDone
        val res = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt_${System.currentTimeMillis()}")
        if (res == TextToSpeech.ERROR) {
            pendingDeviceDone = null
            onDone?.invoke()
        }
    }

    fun destroy() {
        pendingDeviceDone = null
        speechRecognizer?.destroy()
        mediaPlayer?.release()
        tts?.shutdown()
    }
}
