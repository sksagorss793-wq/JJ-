package com.jarvis.system

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class JarvisNotificationService : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val replyCooldowns = ConcurrentHashMap<String, Long>()

    private val supportedPackages = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "org.telegram.messenger",
        "com.facebook.orca"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName == packageName) return
        if (!JarvisPrefs(this).awayEnabled) return
        if (sbn.packageName !in supportedPackages) return

        val notification = sbn.notification ?: return
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) return

        val extras = notification.extras ?: return
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val messageText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (sender.isBlank() || messageText.isBlank()) return
        if (messageText.contains("new messages", ignoreCase = true) ||
            messageText.contains("Checking for", ignoreCase = true)
        ) {
            return
        }

        val key = "${sbn.packageName}:$sender"
        val now = System.currentTimeMillis()
        val last = replyCooldowns[key] ?: 0L
        if (now - last < 45_000L) return

        val replyAction = findReplyAction(notification) ?: return
        val androidRemoteInputs = replyAction.remoteInputs
        if (androidRemoteInputs.isNullOrEmpty()) return

        replyCooldowns[key] = now
        val channel = if (sbn.packageName.contains("whatsapp")) "whatsapp" else "sms"

        scope.launch {
            val api = JarvisApiClient(applicationContext)
            val replyText = api.generateAwayReply(sender, "", channel, messageText) ?: return@launch

            try {
                val replyIntent = Intent()
                val bundle = Bundle()
                for (ri in androidRemoteInputs) {
                    bundle.putCharSequence(ri.resultKey, replyText)
                }
                RemoteInput.addResultsToIntent(androidRemoteInputs, replyIntent, bundle)
                replyAction.actionIntent.send(applicationContext, 0, replyIntent)
            } catch (_: Exception) {
                // Reply action expired
            }
        }
    }

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        return actions.firstOrNull { action ->
            val ri = action.remoteInputs
            ri != null && ri.isNotEmpty()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
