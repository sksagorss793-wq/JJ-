package com.jarvis.system

import android.telecom.Call
import android.telecom.CallScreeningService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JarvisCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: "Unknown"
        val prefs = JarvisPrefs(this)

        if (prefs.awayEnabled) {
            CoroutineScope(Dispatchers.IO).launch {
                JarvisApiClient(applicationContext).generateAwayReply(
                    visitorName = number,
                    contact = number,
                    channel = "call",
                    message = "Incoming phone call from $number while away."
                )
            }
        }

        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()
        respondToCall(callDetails, response)
    }
}
