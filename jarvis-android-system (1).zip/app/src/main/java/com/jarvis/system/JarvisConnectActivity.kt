package com.jarvis.system

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class JarvisConnectActivity : AppCompatActivity() {
    private lateinit var prefs: JarvisPrefs
    private lateinit var webView: WebView
    private var checking = false

    private val probeHttp = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = JarvisPrefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#050B12"))
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(Color.parseColor("#0B1520"))
        }

        val title = TextView(this).apply {
            text = "Google অ্যাকাউন্টে লগইন করে কানেক্ট করুন"
            setTextColor(Color.parseColor("#D4F1FF"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnDone = Button(this).apply {
            text = "যাচাই করুন"
            setOnClickListener { verifyConnection(manual = true) }
        }

        bar.addView(title)
        bar.addView(btnDone)

        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank() && url.startsWith(prefs.serverUrl, ignoreCase = true)) {
                    verifyConnection(manual = false)
                }
            }
        }

        root.addView(bar)
        root.addView(webView)
        setContentView(root)

        webView.loadUrl(prefs.serverUrl)
    }

    private fun verifyConnection(manual: Boolean) {
        if (checking || isFinishing || isDestroyed) return
        checking = true
        val cookie = CookieManager.getInstance().getCookie(prefs.serverUrl).orEmpty()

        CoroutineScope(Dispatchers.IO).launch {
            val ok = try {
                val reqBuilder = Request.Builder().url("${prefs.serverUrl}/api/health")
                if (cookie.isNotBlank()) {
                    reqBuilder.header("Cookie", cookie)
                }
                probeHttp.newCall(reqBuilder.build()).execute().use { res ->
                    val body = res.body?.string().orEmpty()
                    res.code == 200 && body.contains("\"ok\":true")
                }
            } catch (_: Exception) {
                false
            }

            withContext(Dispatchers.Main) {
                checking = false
                if (isFinishing || isDestroyed) return@withContext
                if (ok) {
                    prefs.sessionCookie = cookie
                    CookieManager.getInstance().flush()
                    Toast.makeText(this@JarvisConnectActivity, "Jarvis সার্ভার সংযুক্ত হয়েছে!", Toast.LENGTH_SHORT).show()
                    finish()
                } else if (manual) {
                    Toast.makeText(this@JarvisConnectActivity, "আগে Google লগইন সম্পন্ন করুন।", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
