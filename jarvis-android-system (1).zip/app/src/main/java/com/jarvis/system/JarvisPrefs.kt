package com.jarvis.system

import android.content.Context
import org.json.JSONArray

class JarvisPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_system_prefs", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString("server_url", BuildConfig.DEFAULT_SERVER_URL) ?: BuildConfig.DEFAULT_SERVER_URL
        set(value) {
            val cleaned = value.trim().trimEnd('/')
            if (cleaned.startsWith("http://") || cleaned.startsWith("https://")) {
                prefs.edit().putString("server_url", cleaned).apply()
            }
        }

    var language: String
        get() = prefs.getString("lang", "bn-BD") ?: "bn-BD"
        set(value) = prefs.edit().putString("lang", value).apply()

    var awayEnabled: Boolean
        get() = prefs.getBoolean("away_enabled", false)
        set(value) = prefs.edit().putBoolean("away_enabled", value).apply()

    var voicePersona: String
        get() = prefs.getString("voice_persona", "Zephyr") ?: "Zephyr"
        set(value) = prefs.edit().putString("voice_persona", value).apply()

    var sessionCookie: String
        get() = prefs.getString("session_cookie", "") ?: ""
        set(value) = prefs.edit().putString("session_cookie", value).apply()

    fun getFacts(): List<String> {
        val raw = prefs.getString("facts", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { idx -> arr.optString(idx) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addFact(fact: String) {
        val clean = fact.trim().take(300)
        if (clean.isBlank()) return
        val current = getFacts().toMutableList()
        if (!current.contains(clean)) {
            current.add(clean)
        }
        val arr = JSONArray(current.takeLast(100))
        prefs.edit().putString("facts", arr.toString()).apply()
    }
}
