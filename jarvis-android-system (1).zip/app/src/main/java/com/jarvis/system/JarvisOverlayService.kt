package com.jarvis.system

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class JarvisOverlayService : Service() {
    companion object {
        @Volatile
        var isRunning: Boolean = false
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private var handleView: FrameLayout? = null
    private var statusDot: View? = null
    private var bubbleView: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private lateinit var apiClient: JarvisApiClient
    private lateinit var voiceManager: JarvisVoiceManager
    private var isBusy = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        apiClient = JarvisApiClient(this)
        voiceManager = JarvisVoiceManager(this, apiClient)
        startForegroundNotification()
        if (Settings.canDrawOverlays(this)) {
            attachEdgeHandle()
        }
    }

    private fun startForegroundNotification() {
        val channelId = "jarvis_overlay_channel"
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            channelId,
            "Jarvis System Assistant",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)

        val speakIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, JarvisAssistantActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Jarvis সিস্টেমে চালু আছে")
            .setContentText("এখানে ট্যাপ করুন অথবা স্ক্রিনের ধারের এজ-ট্যাবে ট্যাপ করে কথা বলুন")
            .setSmallIcon(R.drawable.ic_jarvis_orb)
            .setContentIntent(speakIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val hasMic = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            val fgsType = if (hasMic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
            startForeground(101, notification, fgsType)
        } else {
            startForeground(101, notification)
        }
    }

    private fun attachEdgeHandle() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val tabWidth = (22 * density).toInt()
        val tabHeight = (56 * density).toInt()

        val params = WindowManager.LayoutParams(
            tabWidth,
            tabHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth - tabWidth
            y = (resources.displayMetrics.heightPixels * 0.42f).toInt()
        }

        val bParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = params.y
        }
        bubbleParams = bParams

        val bubble = TextView(this).apply {
            visibility = View.GONE
            maxWidth = (250 * density).toInt()
            setTextColor(Color.parseColor("#E3F5FF"))
            textSize = 13f
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EB081420"))
                cornerRadius = 16 * density
                setStroke((1 * density).toInt(), Color.parseColor("#662BD3FF"))
            }
            setOnClickListener { visibility = View.GONE }
        }
        windowManager.addView(bubble, bParams)
        bubbleView = bubble

        val dotSize = (8 * density).toInt()
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2BD3FF"))
            }
            layoutParams = FrameLayout.LayoutParams(dotSize, dotSize, Gravity.CENTER)
        }
        statusDot = dot

        val handle = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#B8081422"))
                cornerRadius = 12 * density
                setStroke((1 * density).toInt(), Color.parseColor("#662BD3FF"))
            }
            elevation = 8f
            addView(dot)
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _: View, event: MotionEvent ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = (initialX + dx).coerceIn(0, screenWidth - tabWidth)
                    params.y = (initialY + dy).coerceIn(40, resources.displayMetrics.heightPixels - tabHeight - 40)
                    windowManager.updateViewLayout(handle, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (event.eventTime - event.downTime >= 650L) {
                            val intent = Intent(this, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                        } else {
                            triggerVoiceTurn(handle, params, tabWidth, screenWidth, density)
                        }
                    } else {
                        // Snap neatly flush to nearest screen edge so it never blocks content
                        params.x = if (params.x + tabWidth / 2 < screenWidth / 2) 0 else screenWidth - tabWidth
                        windowManager.updateViewLayout(handle, params)
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(handle, params)
        handleView = handle
    }

    private fun setDotColor(hex: String) {
        (statusDot?.background as? GradientDrawable)?.setColor(Color.parseColor(hex))
    }

    private fun showBubble(text: String, params: WindowManager.LayoutParams, tabWidth: Int, screenWidth: Int, density: Float, autoHideMs: Long = 0L) {
        uiHandler.removeCallbacksAndMessages(null)
        val bParams = bubbleParams ?: return
        val onRight = params.x > screenWidth / 2
        bParams.x = if (onRight) (screenWidth - tabWidth - (265 * density).toInt()).coerceAtLeast((16 * density).toInt()) else tabWidth + (10 * density).toInt()
        bParams.y = params.y
        bubbleView?.apply {
            this.text = text
            visibility = View.VISIBLE
            windowManager.updateViewLayout(this, bParams)
            if (autoHideMs > 0L) {
                uiHandler.postDelayed({ visibility = View.GONE }, autoHideMs)
            }
        }
    }

    private fun resetHandle() {
        isBusy = false
        setDotColor("#2BD3FF")
        handleView?.alpha = 0.85f
    }

    private fun triggerVoiceTurn(
        handle: FrameLayout,
        params: WindowManager.LayoutParams,
        tabWidth: Int,
        screenWidth: Int,
        density: Float
    ) {
        if (isBusy) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showBubble("মাইক্রোফোন অনুমতি দিতে Jarvis অ্যাপটি খুলুন", params, tabWidth, screenWidth, density, 4000L)
            return
        }

        isBusy = true
        handle.alpha = 1f
        setDotColor("#FBBF24")
        showBubble("শুনছি…", params, tabWidth, screenWidth, density)

        voiceManager.startSingleListen(
            onListening = {
                setDotColor("#34D399")
                showBubble("বলুন, শুনছি…", params, tabWidth, screenWidth, density)
            },
            onResult = { spoken ->
                setDotColor("#FBBF24")
                showBubble("ভাবছি: $spoken", params, tabWidth, screenWidth, density)
                serviceScope.launch {
                    try {
                        val reply = apiClient.askJarvis(spoken)
                        showBubble(reply, params, tabWidth, screenWidth, density, 9000L)
                        voiceManager.speak(reply) {
                            resetHandle()
                        }
                    } catch (e: Exception) {
                        showBubble(e.message ?: "ত্রুটি হয়েছে", params, tabWidth, screenWidth, density, 5000L)
                        resetHandle()
                    }
                }
            },
            onError = { err ->
                showBubble(err, params, tabWidth, screenWidth, density, 3000L)
                resetHandle()
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        uiHandler.removeCallbacksAndMessages(null)
        handleView?.let { windowManager.removeView(it) }
        bubbleView?.let { windowManager.removeView(it) }
        voiceManager.destroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
