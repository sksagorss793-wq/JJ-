package com.jarvis.system

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: JarvisPrefs
    private lateinit var apiClient: JarvisApiClient
    private lateinit var voiceManager: JarvisVoiceManager
    private lateinit var deviceController: JarvisDeviceController

    private lateinit var tvStatus: TextView
    private lateinit var tvChatLog: TextView
    private lateinit var scrollChat: ScrollView
    private lateinit var etInput: EditText
    private lateinit var btnOverlayOrb: Button
    private lateinit var btnAwayMode: Button
    private lateinit var btnLang: Button
    private lateinit var btnPermsOverlay: Button
    private lateinit var btnPermsControl: Button
    private lateinit var btnPermsNotif: Button
    private lateinit var btnConnect: Button

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = JarvisPrefs(this)
        apiClient = JarvisApiClient(this)
        voiceManager = JarvisVoiceManager(this, apiClient)
        deviceController = JarvisDeviceController(this)

        tvStatus = findViewById(R.id.tvStatus)
        tvChatLog = findViewById(R.id.tvChatLog)
        scrollChat = findViewById(R.id.scrollChat)
        etInput = findViewById(R.id.etInput)
        btnOverlayOrb = findViewById(R.id.btnOverlayOrb)
        btnAwayMode = findViewById(R.id.btnAwayMode)
        btnLang = findViewById(R.id.btnLang)
        btnPermsOverlay = findViewById(R.id.btnPermsOverlay)
        btnPermsControl = findViewById(R.id.btnPermsControl)
        btnPermsNotif = findViewById(R.id.btnPermsNotif)
        btnConnect = findViewById(R.id.btnConnect)

        requestRuntimePermissions()
        refreshButtons()
        appendChat("Jarvis", "হ্যালো! আমি জার্ভিস — আপনার ফোনের পূর্ণাঙ্গ বন্ধু ও অ্যাসিস্ট্যান্ট। সাধারণ আড্ডা, গান, কল, অ্যালার্ম বা স্ক্রিন কন্ট্রোল (Back/Home/Scroll/Screenshot) যা খুশি বলুন। লাইভ AI কথোপকথনের জন্য একবার 'Google কানেক্ট' এবং পূর্ণ ফোন কন্ট্রোলের জন্য 'Control' অন করুন।")

        findViewById<Button>(R.id.btnSend).setOnClickListener { submitInput() }

        etInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitInput()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnMic).setOnClickListener {
            voiceManager.startSingleListen(
                onListening = { tvStatus.text = "শুনছি…" },
                onResult = { spoken -> sendTurn(spoken) },
                onError = { err -> tvStatus.text = err }
            )
        }

        btnLang.setOnClickListener {
            prefs.language = if (prefs.language == "bn-BD") "en-US" else "bn-BD"
            refreshButtons()
        }

        findViewById<Button>(R.id.btnServer).setOnClickListener {
            showServerUrlDialog()
        }

        btnConnect.setOnClickListener {
            startActivity(Intent(this, JarvisConnectActivity::class.java))
        }

        btnOverlayOrb.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, JarvisOverlayService::class.java)
            if (JarvisOverlayService.isRunning) {
                stopService(serviceIntent)
                JarvisOverlayService.isRunning = false
            } else {
                ContextCompat.startForegroundService(this, serviceIntent)
                JarvisOverlayService.isRunning = true
            }
            refreshButtons()
        }

        btnAwayMode.setOnClickListener {
            val next = !prefs.awayEnabled
            prefs.awayEnabled = next
            refreshButtons()
            CoroutineScope(Dispatchers.Main).launch {
                apiClient.syncAwayEnabled(next)
            }
        }

        btnPermsOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        btnPermsControl.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnPermsNotif.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.btnPermsCallScreen).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                    return@setOnClickListener
                }
            }
            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }

        findViewById<Button>(R.id.btnPermsAssist).setOnClickListener {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        }

        findViewById<Button>(R.id.btnQuickBrief).setOnClickListener {
            sendTurn(
                if (prefs.language == "bn-BD")
                    "আমাকে আজকের সংক্ষিপ্ত খবর ও আবহাওয়ার ব্রিফিং দাও।"
                else
                    "Give me a quick briefing on today's news and weather."
            )
        }

        findViewById<Button>(R.id.btnQuickTorch).setOnClickListener {
            val on = deviceController.toggleFlashlight()
            appendChat("Jarvis", if (on) "ফ্ল্যাশলাইট জ্বালিয়ে দিয়েছি।" else "ফ্ল্যাশলাইট বন্ধ করেছি।")
        }

        findViewById<Button>(R.id.btnQuickBattery).setOnClickListener {
            val pct = deviceController.getBatteryPercent()
            appendChat("Jarvis", "আপনার ফোনে এখন $pct% চার্জ আছে।")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
    }

    private fun submitInput() {
        val text = etInput.text.toString().trim()
        if (text.isNotBlank()) {
            etInput.setText("")
            sendTurn(text)
        }
    }

    private fun showServerUrlDialog() {
        val input = EditText(this).apply {
            setText(prefs.serverUrl)
            setTextColor(0xFFFFFFFF.toInt())
        }
        AlertDialog.Builder(this)
            .setTitle("Jarvis Backend Server URL")
            .setView(input)
            .setPositiveButton("সেভ করুন") { _, _ ->
                prefs.serverUrl = input.text.toString()
            }
            .setNeutralButton("Google কানেক্ট") { _, _ ->
                prefs.serverUrl = input.text.toString()
                startActivity(Intent(this, JarvisConnectActivity::class.java))
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun sendTurn(text: String) {
        appendChat("আপনি", text)
        tvStatus.text = "ভাবছি…"
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val reply = apiClient.askJarvis(text)
                appendChat("Jarvis", reply)
                tvStatus.text = "বলছি…"
                voiceManager.speak(reply) {
                    tvStatus.text = "প্রস্তুত"
                }
            } catch (e: Exception) {
                appendChat("Error", e.message ?: "Request failed")
                tvStatus.text = "প্রস্তুত"
            }
        }
    }

    private fun appendChat(who: String, msg: String) {
        val current = tvChatLog.text.toString()
        val line = "[$who]\n$msg\n\n"
        tvChatLog.text = current + line
        scrollChat.post { scrollChat.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun refreshButtons() {
        btnLang.text = if (prefs.language == "bn-BD") "English" else "বাংলা"
        btnOverlayOrb.text = if (JarvisOverlayService.isRunning) "এজ ট্যাব বন্ধ" else "এজ ট্যাব চালু"
        btnAwayMode.text = if (prefs.awayEnabled) "অটো-রিপ্লাই: চালু" else "অটো-রিপ্লাই: বন্ধ"
        btnPermsOverlay.text = if (Settings.canDrawOverlays(this)) "✓ Overlay" else "Overlay"
        btnPermsControl.text = if (JarvisAccessibilityService.instance != null) "✓ Control" else "Control"
        val enabledNotif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        btnPermsNotif.text = if (enabledNotif.contains(packageName)) "✓ Notif" else "Notif"
        btnConnect.text = if (prefs.sessionCookie.isNotBlank()) "✓ Google কানেক্ট" else "Google কানেক্ট"
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
