package com.jarvis.system

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat

class JarvisDeviceController(private val context: Context) {

    private var torchEnabled = false

    fun toggleFlashlight(): Boolean {
        val next = !torchEnabled
        if (setFlashlight(next)) {
            torchEnabled = next
        }
        return torchEnabled
    }

    fun getBatteryPercent(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    fun getPhonebookContactsSummary(limit: Int = 25): org.json.JSONArray {
        val arr = org.json.JSONArray()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return arr
        }
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val seen = HashSet<String>()
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && arr.length() < limit) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx)?.trim().orEmpty() else ""
                    val num = if (numIdx >= 0) cursor.getString(numIdx)?.trim().orEmpty() else ""
                    if (name.isNotBlank() && num.isNotBlank() && seen.add(name.lowercase())) {
                        arr.put(org.json.JSONObject().apply {
                            put("name", name)
                            put("phone", num)
                        })
                    }
                }
            }
        } catch (_: Exception) {
        }
        return arr
    }

    fun handleLocalSystemCommand(userText: String): String? {
        val trimmed = userText.trim()
        val lower = normalizeDigits(trimmed).lowercase()
        val bn = isBangla(userText)

        // Accessibility Full Phone UI Controls
        if (lower == "back" || lower == "go back" || lower.contains("পিছনে যাও") || lower.contains("ব্যাকে যাও") || lower == "ব্যাক করো") {
            return runAccessibilityAction("back", bn)
        }
        if (lower == "home" || lower == "go home" || lower == "home screen" || lower.contains("হোমে যাও") || lower.contains("হোম স্ক্রিনে")) {
            return runAccessibilityAction("home", bn)
        }
        if (lower == "recents" || lower == "recent apps" || lower.contains("রিসেন্ট অ্যাপ") || lower.contains("রিসেন্ট দেখাও")) {
            return runAccessibilityAction("recents", bn)
        }
        if (lower == "open notifications" || lower == "show notifications" || lower.contains("নোটিফিকেশন নামাও") || lower.contains("নোটিফিকেশন দেখাও")) {
            return runAccessibilityAction("notifications", bn)
        }
        if (lower == "quick settings" || lower.contains("কুইক সেটিংস")) {
            return runAccessibilityAction("quick_settings", bn)
        }
        if (lower == "lock screen" || lower == "lock phone" || lower.contains("ফোন লক") || lower.contains("স্ক্রিন লক")) {
            return runAccessibilityAction("lock_screen", bn)
        }
        if (lower == "screenshot" || lower == "take screenshot" || lower.contains("স্ক্রিনশট")) {
            return runAccessibilityAction("screenshot", bn)
        }
        if (lower == "scroll down" || lower.contains("নিচে স্ক্রল") || lower == "নিচে যাও") {
            return runAccessibilityAction("scroll_down", bn)
        }
        if (lower == "scroll up" || lower.contains("উপরে স্ক্রল") || lower == "উপরে যাও") {
            return runAccessibilityAction("scroll_up", bn)
        }

        val enTapMatch = Regex("^(?:tap|click|press) +(.+)$", RegexOption.IGNORE_CASE).find(trimmed)
        val bnTapMatch = Regex("^(.+?)(?:-এ| এ|তে)? *(?:ক্লিক করো|ট্যাপ করো|চাপো)$").find(trimmed)
        val tapTarget = enTapMatch?.groupValues?.get(1)?.trim() ?: bnTapMatch?.groupValues?.get(1)?.trim()
        if (!tapTarget.isNullOrBlank()) {
            return runAccessibilityAction("tap_text", bn, tapTarget)
        }

        val enTypeMatch = Regex("^(?:type|write) +(.+)$", RegexOption.IGNORE_CASE).find(trimmed)
        val bnTypeMatch = Regex("^(?:লিখো|টাইপ করো) +(.+)$").find(trimmed)
        val typeValue = enTypeMatch?.groupValues?.get(1)?.trim() ?: bnTypeMatch?.groupValues?.get(1)?.trim()
        if (!typeValue.isNullOrBlank()) {
            return runAccessibilityAction("type_text", bn, typeValue)
        }

        // Volume & Media controls
        if (lower.contains("volume up") || lower == "louder" || lower.contains("সাউন্ড বাড়াও") || lower.contains("ভলিউম বাড়াও") || lower.contains("আওয়াজ বাড়াও")) {
            return performAudioAction("volume_up", bn)
        }
        if (lower.contains("volume down") || lower == "quieter" || lower.contains("সাউন্ড কমাও") || lower.contains("ভলিউম কমাও") || lower.contains("আওয়াজ কমাও")) {
            return performAudioAction("volume_down", bn)
        }
        if (lower == "mute" || lower == "silent" || lower == "silent mode" || lower.contains("মিউট করো") || lower.contains("সাইলেন্ট করো") || lower.contains("সাউন্ড বন্ধ")) {
            return performAudioAction("mute", bn)
        }
        if (lower == "unmute" || lower.contains("আনমিউট") || lower.contains("সাউন্ড চালু")) {
            return performAudioAction("unmute", bn)
        }
        if (lower == "play music" || lower == "pause music" || lower == "play pause" || lower.contains("গান চালাও") || lower.contains("গান থামাও") || lower == "পজ করো" || lower == "প্লে করো") {
            return performMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, if (bn) "মিডিয়া প্লে/পজ করেছি।" else "Toggled media playback.")
        }
        if (lower == "next song" || lower == "next track" || lower.contains("পরের গান") || lower.contains("নেক্সট গান")) {
            return performMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, if (bn) "পরের গানে যাচ্ছি।" else "Skipped to next track.")
        }
        if (lower == "previous song" || lower == "previous track" || lower.contains("আগের গান")) {
            return performMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, if (bn) "আগের গানে ফিরে গেছি।" else "Went back to previous track.")
        }

        // Flashlight control
        if (lower.contains("flashlight on") || lower.contains("torch on") ||
            (lower.contains("টর্চ") && (lower.contains("চালু") || lower.contains("অন") || lower.contains("জ্বালাও")))
        ) {
            return if (setFlashlight(true)) {
                torchEnabled = true
                if (bn) "ফ্ল্যাশলাইট জ্বালিয়ে দিয়েছি!" else "Flashlight is on!"
            } else {
                if (bn) "ফ্ল্যাশলাইট চালু করা যায়নি।" else "Could not turn on flashlight."
            }
        }

        if (lower.contains("flashlight off") || lower.contains("torch off") ||
            (lower.contains("টর্চ") && (lower.contains("বন্ধ") || lower.contains("অফ") || lower.contains("নেভাও")))
        ) {
            return if (setFlashlight(false)) {
                torchEnabled = false
                if (bn) "ফ্ল্যাশলাইট বন্ধ করেছি।" else "Flashlight turned off."
            } else {
                if (bn) "ফ্ল্যাশলাইট বন্ধ করা যায়নি।" else "Could not turn off flashlight."
            }
        }

        // Battery level
        if (lower.contains("battery") || lower.contains("ব্যাটারি") || lower.contains("চার্জ কত")) {
            val pct = getBatteryPercent()
            return if (bn) "আপনার ফোনে এখন $pct% চার্জ আছে।" else "Your phone battery is at $pct%."
        }

        // Current time / date locally
        if (lower.contains("what time") || lower.contains("কয়টা বাজে") || lower.contains("সময় কত")) {
            val fmt = java.text.SimpleDateFormat("h:mm a, EEEE, d MMM", java.util.Locale.getDefault())
            val now = fmt.format(java.util.Date())
            return if (bn) "এখন সময় $now।" else "It is currently $now."
        }

        // Quick Camera / Wi-Fi / Bluetooth shortcuts
        if (lower == "open camera" || lower == "camera" || lower.contains("ক্যামেরা খোলো") || lower.contains("ছবি তোলো")) {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            return try {
                context.startActivity(intent)
                if (bn) "ক্যামেরা খুলে দিয়েছি, হাসুন!" else "Camera is open!"
            } catch (_: Exception) {
                if (launchInstalledApp("camera")) (if (bn) "ক্যামেরা খুলেছি।" else "Camera opened.") else null
            }
        }

        if (lower == "wifi settings" || lower == "open wifi" || lower.contains("ওয়াইফাই")) {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return if (bn) "Wi-Fi সেটিংস খুলেছি।" else "Opened Wi-Fi settings."
        }

        if (lower == "bluetooth settings" || lower == "open bluetooth" || lower.contains("ব্লুটুথ")) {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return if (bn) "Bluetooth সেটিংস খুলেছি।" else "Opened Bluetooth settings."
        }

        // Local Alarm ("7:30 অ্যালার্ম দাও" / "set alarm for 7:30")
        val alarmMatch = Regex("([0-9]{1,2}):([0-9]{2}).*(?:alarm|অ্যালার্ম|এলার্ম)", RegexOption.IGNORE_CASE).find(lower)
            ?: Regex("(?:alarm|অ্যালার্ম|এলার্ম).*?([0-9]{1,2}):([0-9]{2})", RegexOption.IGNORE_CASE).find(lower)
        if (alarmMatch != null) {
            val h = (alarmMatch.groupValues[1].toIntOrNull() ?: 7).coerceIn(0, 23)
            val m = (alarmMatch.groupValues[2].toIntOrNull() ?: 0).coerceIn(0, 59)
            return startSystemAlarm(h, m, "Jarvis Alarm")
        }

        // Local Timer in Bengali or English
        val bnTimer = Regex("([0-9]+) *(?:মিনিট|মিনিটের|minute|minutes|min) *(?:এর )?(?:টাইমার|timer)").find(lower)
        if (bnTimer != null) {
            val mins = bnTimer.groupValues[1].toIntOrNull() ?: 1
            val sec = (mins * 60).coerceIn(1, 86400)
            return startSystemTimer(sec, "Jarvis Timer")
        }
        val secTimer = Regex("([0-9]+) *(?:সেকেন্ড|সেকেন্ডের|second|seconds|sec) *(?:এর )?(?:টাইমার|timer)").find(lower)
        if (secTimer != null) {
            val sec = (secTimer.groupValues[1].toIntOrNull() ?: 30).coerceIn(1, 86400)
            return startSystemTimer(sec, "Jarvis Timer")
        }

        // YouTube & Google search shortcuts
        val ytBnMatch = Regex("^(?:ইউটিউবে|youtube-এ|youtube এ) +(.+?) *(?:খোঁজো|সার্চ করো|চালাও|দেখাও)$", RegexOption.IGNORE_CASE).find(trimmed)
        val ytEnMatch = Regex("^(?:search youtube for|play) +(.+?) *(?:on youtube)?$", RegexOption.IGNORE_CASE).find(trimmed)
        val ytQuery = ytBnMatch?.groupValues?.get(1)?.trim() ?: if (lower.contains("youtube")) ytEnMatch?.groupValues?.get(1)?.trim() else null
        if (!ytQuery.isNullOrBlank()) {
            val url = "https://www.youtube.com/results?search_query=${Uri.encode(ytQuery)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return if (bn) "YouTube-এ '$ytQuery' খুঁজছি!" else "Searching YouTube for $ytQuery."
        }

        val googleBnMatch = Regex("^(?:গুগলে|google-এ|google এ) +(.+?) *(?:খোঁজো|সার্চ করো|দেখাও)$", RegexOption.IGNORE_CASE).find(trimmed)
        val googleEnMatch = Regex("^search google for +(.+)$", RegexOption.IGNORE_CASE).find(trimmed)
        val gQuery = googleBnMatch?.groupValues?.get(1)?.trim() ?: googleEnMatch?.groupValues?.get(1)?.trim()
        if (!gQuery.isNullOrBlank()) {
            val url = "https://www.google.com/search?q=${Uri.encode(gQuery)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return if (bn) "Google-এ '$gQuery' সার্চ করে দিলাম।" else "Searching Google for $gQuery."
        }

        // Direct Call in Bengali or English ("আম্মুকে কল দাও" / "call Mom")
        val bnCallMatch = Regex("^(.+?) *(?:কে|রে)? *(?:কল দাও|কল করো|ফোন দাও|ফোন করো|call দাও)$").find(trimmed)
        val enCallMatch = Regex("^(?:call|dial) +(.+)$", RegexOption.IGNORE_CASE).find(trimmed)
        val callTarget = bnCallMatch?.groupValues?.get(1)?.trim() ?: enCallMatch?.groupValues?.get(1)?.trim()
        if (!callTarget.isNullOrBlank()) {
            val args = org.json.JSONObject().put("number", callTarget)
            return executeTool("call_number", args)
        }

        // Open installed app by name (English & Bengali: "open Instagram", "Instagram খোলো", "ইনস্টাগ্রাম চালু করো")
        val enOpenMatch = Regex("^(?:open|launch|start) +([a-zA-Z0-9 ._-]+)$", RegexOption.IGNORE_CASE).find(trimmed)
        val bnOpenMatch = Regex("^(.+?) *(?:অ্যাপটা |অ্যাপ )?(?:খোলো|খুলো|ওপেন করো|চালু করো|খুলে দাও)$").find(trimmed)
        val rawAppQuery = enOpenMatch?.groupValues?.get(1)?.trim() ?: bnOpenMatch?.groupValues?.get(1)?.trim()
        if (!rawAppQuery.isNullOrBlank()) {
            val resolvedQuery = mapAppAlias(rawAppQuery)
            if (launchInstalledApp(resolvedQuery)) {
                return if (bn) "$rawAppQuery খুলে দিয়েছি!" else "Opening $rawAppQuery!"
            }
        }

        return null
    }

    private fun runAccessibilityAction(action: String, bn: Boolean, value: String = ""): String {
        val acc = JarvisAccessibilityService.instance
        if (acc == null) {
            return if (bn) {
                "পুরো ফোন কন্ট্রোল করতে উপরের 'Control' বাটনে ট্যাপ করে Accessibility অন করে দিন — তারপর একবার বললেই কাজ করবে!"
            } else {
                "Please enable 'Control' (Accessibility) at the top of Jarvis so I can control your phone screen."
            }
        }
        val ok = when (action) {
            "back" -> acc.goBack()
            "home" -> acc.goHome()
            "recents" -> acc.openRecents()
            "notifications" -> acc.openNotifications()
            "quick_settings" -> acc.openQuickSettings()
            "lock_screen" -> acc.lockScreen()
            "screenshot" -> acc.takeScreenshot()
            "scroll_down" -> acc.scroll(true)
            "scroll_up" -> acc.scroll(false)
            "tap_text" -> if (value.isNotBlank()) acc.tapText(value) else false
            "type_text" -> if (value.isNotBlank()) acc.typeText(value) else false
            else -> false
        }
        return if (ok) {
            when (action) {
                "back" -> if (bn) "পিছনে গেলাম।" else "Went back."
                "home" -> if (bn) "হোম স্ক্রিনে এসেছি।" else "Went to Home screen."
                "recents" -> if (bn) "রিসেন্ট অ্যাপগুলো দেখাচ্ছি।" else "Opened recent apps."
                "notifications" -> if (bn) "নোটিফিকেশন নামিয়েছি।" else "Opened notifications."
                "quick_settings" -> if (bn) "কুইক সেটিংস খুলেছি।" else "Opened quick settings."
                "lock_screen" -> if (bn) "ফোন লক করে দিলাম।" else "Screen locked."
                "screenshot" -> if (bn) "স্ক্রিনশট তুলে নিয়েছি!" else "Took a screenshot!"
                "scroll_down" -> if (bn) "নিচে স্ক্রল করেছি।" else "Scrolled down."
                "scroll_up" -> if (bn) "উপরে স্ক্রল করেছি।" else "Scrolled up."
                "tap_text" -> if (bn) "'$value'-এ ট্যাপ করেছি।" else "Tapped '$value'."
                "type_text" -> if (bn) "'$value' লিখে দিয়েছি।" else "Typed '$value'."
                else -> if (bn) "হয়ে গেছে।" else "Done."
            }
        } else {
            if (bn) "এই স্ক্রিনে কাজটি করা যায়নি।" else "Could not perform that action on the current screen."
        }
    }

    private fun performAudioAction(action: String, bn: Boolean): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (action) {
            "volume_up" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                if (bn) "ভলিউম বাড়িয়ে দিলাম।" else "Volume increased."
            }
            "volume_down" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                if (bn) "ভলিউম কমিয়ে দিলাম।" else "Volume decreased."
            }
            "mute" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                if (bn) "সাউন্ড মিউট করে দিয়েছি।" else "Audio muted."
            }
            "unmute" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                if (bn) "সাউন্ড আবার চালু করেছি।" else "Audio unmuted."
            }
            else -> if (bn) "হয়েছে।" else "Done."
        }
    }

    private fun performMediaKey(keyCode: Int, reply: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return reply
    }

    private fun startSystemAlarm(hour: Int, minute: Int, label: String): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}-এ অ্যালার্ম সেট করেছি!"
        } catch (_: Exception) {
            "এই ডিভাইসে অ্যালার্ম সেট করা যায়নি।"
        }
    }

    private fun startSystemTimer(sec: Int, label: String): String {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, sec)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "$sec সেকেন্ডের সিস্টেম টাইমার সেট করেছি।"
        } catch (_: Exception) {
            "এই ডিভাইসে টাইমার সেট করা যায়নি।"
        }
    }

    private fun normalizeDigits(input: String): String {
        val bn = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        var out = input
        for (i in bn.indices) {
            out = out.replace(bn[i], ('0' + i))
        }
        return out
    }

    private fun mapAppAlias(raw: String): String {
        val q = raw.trim().lowercase()
        val aliases = mapOf(
            "ইনস্টাগ্রাম" to "instagram",
            "হোয়াটসঅ্যাপ" to "whatsapp",
            "হোয়াটসঅ্যাপে" to "whatsapp",
            "ফেসবুক" to "facebook",
            "ইউটিউব" to "youtube",
            "ক্রোম" to "chrome",
            "ক্যামেরা" to "camera",
            "গ্যালারি" to "gallery",
            "সেটিংস" to "settings",
            "সেটিং" to "settings",
            "মেসেঞ্জার" to "messenger",
            "টেলিগ্রাম" to "telegram",
            "ক্যালকুলেটর" to "calculator",
            "জিমেইল" to "gmail",
            "ম্যাপস" to "maps",
            "ম্যাপ" to "maps",
            "প্লে স্টোর" to "play store",
            "প্লেস্টোর" to "play store",
            "ফোন" to "phone",
            "ঘড়ি" to "clock",
            "ক্যালেন্ডার" to "calendar",
            "স্পটিফাই" to "spotify",
            "মিউজিক" to "music",
            "গুগল" to "google"
        )
        return aliases[q] ?: raw.trim()
    }

    fun executeTool(name: String, argsJson: org.json.JSONObject): String {
        val bn = JarvisPrefs(context).language == "bn-BD"
        return when (name) {
            "open_app" -> {
                val rawName = argsJson.optString("appName").ifBlank { argsJson.optString("name") }.trim()
                if (rawName.isBlank()) return if (bn) "অ্যাপের নাম পাওয়া যায়নি।" else "No app name provided."
                val resolved = mapAppAlias(rawName)
                if (launchInstalledApp(resolved)) {
                    if (bn) "$rawName খুলে দিয়েছি!" else "Opened $rawName."
                } else {
                    if (bn) "$rawName অ্যাপটি ফোনে খুঁজে পাওয়া যায়নি।" else "Could not find $rawName installed on this phone."
                }
            }
            "set_alarm" -> {
                val hour = argsJson.optInt("hour", 7).coerceIn(0, 23)
                val minute = argsJson.optInt("minute", 0).coerceIn(0, 59)
                val label = argsJson.optString("message", "Jarvis Alarm")
                startSystemAlarm(hour, minute, label)
            }
            "device_action" -> {
                val action = argsJson.optString("action").trim()
                val value = argsJson.optString("value").trim()
                when (action) {
                    "flashlight_on" -> if (setFlashlight(true)) { torchEnabled = true; if (bn) "ফ্ল্যাশলাইট জ্বালিয়েছি!" else "Flashlight on." } else "Failed"
                    "flashlight_off" -> if (setFlashlight(false)) { torchEnabled = false; if (bn) "ফ্ল্যাশলাইট বন্ধ করেছি।" else "Flashlight off." } else "Failed"
                    "volume_up", "volume_down", "mute", "unmute" -> performAudioAction(action, bn)
                    "media_play_pause" -> performMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, if (bn) "মিডিয়া প্লে/পজ করেছি।" else "Toggled playback.")
                    "media_next" -> performMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, if (bn) "পরের গান চালাচ্ছি।" else "Next track.")
                    "media_prev" -> performMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, if (bn) "আগের গানে গেলাম।" else "Previous track.")
                    "wifi_settings" -> {
                        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        if (bn) "Wi-Fi সেটিংস খুলেছি।" else "Opened Wi-Fi settings."
                    }
                    "bluetooth_settings" -> {
                        context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        if (bn) "Bluetooth সেটিংস খুলেছি।" else "Opened Bluetooth settings."
                    }
                    "camera" -> {
                        context.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        if (bn) "ক্যামেরা খুলে দিয়েছি।" else "Opened Camera."
                    }
                    "back", "home", "recents", "notifications", "quick_settings",
                    "lock_screen", "screenshot", "scroll_down", "scroll_up", "tap_text", "type_text" ->
                        runAccessibilityAction(action, bn, value)
                    else -> if (bn) "অ্যাকশনটি সমর্থিত নয়।" else "Unsupported action: $action"
                }
            }
            "call_number" -> {
                val rawNum = argsJson.optString("number").ifBlank { argsJson.optString("contactName") }
                val number = resolvePhoneNumber(rawNum).replace(Regex("[^0-9+]"), "")
                if (number.isBlank()) return "No valid number found."
                val hasCallPerm = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CALL_PHONE
                ) == PackageManager.PERMISSION_GRANTED
                val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
                val intent = Intent(action, Uri.parse("tel:$number")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                if (hasCallPerm) "Calling $number now." else "Dialer opened for $number."
            }
            "send_sms" -> {
                val number = resolvePhoneNumber(argsJson.optString("number")).replace(Regex("[^0-9+]"), "")
                val text = argsJson.optString("text")
                if (number.isBlank()) return "No valid number found."
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                    putExtra("sms_body", text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "SMS screen opened for $number."
            }
            "send_whatsapp" -> {
                val number = resolvePhoneNumber(argsJson.optString("number")).replace(Regex("[^0-9]"), "")
                val text = Uri.encode(argsJson.optString("text"))
                val url = if (number.isNotBlank()) "https://wa.me/$number?text=$text" else "https://wa.me/?text=$text"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "WhatsApp opened."
            }
            "open_link" -> {
                val url = argsJson.optString("url")
                if (url.startsWith("https://")) {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    "Opened link."
                } else {
                    "Only https links supported."
                }
            }
            "set_timer" -> {
                val sec = argsJson.optInt("seconds", 60).coerceIn(1, 86400)
                val label = argsJson.optString("label", "Jarvis Timer")
                startSystemTimer(sec, label)
            }
            "remember" -> {
                val fact = argsJson.optString("fact")
                JarvisPrefs(context).addFact(fact)
                "Saved to memory."
            }
            else -> "Completed $name."
        }
    }

    private fun resolvePhoneNumber(input: String): String {
        val cleaned = input.trim()
        val digitsOnly = cleaned.replace(Regex("[^0-9+]"), "")
        if (digitsOnly.length >= 6) return digitsOnly

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return cleaned
        }

        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else ""
                    val num = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                    if (name.contains(cleaned, ignoreCase = true) && num.isNotBlank()) {
                        return num
                    }
                }
            }
        } catch (_: Exception) {
        }
        return cleaned
    }

    fun launchInstalledApp(query: String): Boolean {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        val normQuery = query.replace(" ", "")
        val match = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString()
            val normLabel = label.replace(" ", "")
            label.equals(query, ignoreCase = true) ||
                label.contains(query, ignoreCase = true) ||
                normLabel.contains(normQuery, ignoreCase = true) ||
                info.activityInfo.packageName.contains(normQuery, ignoreCase = true)
        } ?: return false

        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }

    fun setFlashlight(on: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(cameraId, on)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun isBangla(text: String): Boolean = text.any { it in '\u0980'..'\u09FF' }
}
